require.config({
    baseUrl: '.',
    paths: {
        'angular': 'node_modules/angular/angular.min',
        'domReady': 'node_modules/requirejs-domready/domReady',
        'angularBootstrap': 'node_modules/angular-bootstrap/ui-bootstrap-tpls',
        'app': 'app/app',
		'moment': 'node_modules/moment/moment',
//		'moment_range': 'node_modules/moment-range/dist/moment-range',
        'controller': 'js/controllers/firstController',
        'directive': 'js/directives/isolateScope',
        'ratingDirective': 'js/directives/ratingDirective',
		'dateRangeDirective': 'js/directives/dateRangeDirective'
    },
    shim: {
        angular: { exports: 'angular'},
		moment: { exports: 'moment'	},
        angularBootstrap: {
            deps: ['angular']
        },
        app: {
            deps: ['angular']
        }/*,
		moment: {
			deps: ['angular']
		}*/
    }
});

require(['domReady', 
         'angular', 
         'app',
         'angularBootstrap',
         'controller', 
         'directive',
         'ratingDirective',
		 'dateRangeDirective'
], function (domReady,
              angular,
              app,
              angularBootstrap,
              controller,
              directive,
              ratingDirective,
			  dateRangeDirective
			 ) {
    domReady(function () {
        angular.bootstrap(document, ['app']);
    });
});

// Bootstrap app without using domReady
/* 
angular.element(document).ready(function () {
        angular.bootstrap(document, ['app']);
    });

*/