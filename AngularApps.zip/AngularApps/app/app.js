var requiredModule = ['angular', 'moment'];

define('app', requiredModule, function (angular) {
    return angular.module('app', ['ui.bootstrap']);
});