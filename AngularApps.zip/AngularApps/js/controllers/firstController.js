define('controller', [    
    'app'
], function(app) {
    app.controller('firstController', ['$scope', '$sce', function ($scope, $sce) {
               
        $scope.nameController = 'Barinder';
        $scope.ageController = 25;
        $scope.callbackAndFunc = function () {
            alert($scope.nameController + ' -- '+ $scope.ageController);
        };
        
        
        $scope.config = {
            ssoVal: 502565930,
            keyPressFunc: function(event) {
                if (this.ssoVal.length === 0 && event.which == 48) {
                    event.preventDefault();
                    alert('first charcater cant be zero');
                }
                if (event.which < 48 || event.which > 57 || this.ssoVal.length === 9) {
                    event.preventDefault();
                    alert('invalid input');
                    
                }
                
            }
        };
        
       /*
        * Carousel implementation
        */
        $scope.tabIndex = 0;
        
        $scope.carouselData = [ 
            {
                'imagePath': 'img/1.jpg',
                'text': 'Image1'
            
            },
            {
                'imagePath': 'img/2.jpeg',
                'text': 'Image2'
            
            },
            {
                'imagePath': 'img/3.jpeg',
                'text': 'Image3'
            
            }
        ];
		
		 $scope.myInterval = 3000;
		  $scope.slides = [
			{
			  image: 'http://lorempixel.com/400/200/'
			},
			{
			  image: 'http://lorempixel.com/400/200/food'
			},
			{
			  image: 'http://lorempixel.com/400/200/sports'
			},
			{
			  image: 'http://lorempixel.com/400/200/people'
			}
		  ];
        
        $scope.selectOption = function (index) {
           //$scope.tabIndex++;
           $scope.tabIndex = index;
            
            
        };
       
       /*
        * Implementing rating Field
        */
       
       $scope.ratings = [
          {
             current: 5,
             max: 10
          }
       ];
       $scope.getSelectedRating = function (ratingVal) {
          console.log(ratingVal);
       }
        
        
    }]);
});