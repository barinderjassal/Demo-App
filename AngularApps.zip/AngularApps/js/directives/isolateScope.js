define('directive', [
    'app'
], function (app) {
    app.directive('isolateScopeDirective', [function () {
        return {
            restrict: 'EA',
            scope: {
                name: '@',
                age: '=',
                callbackFunc: '&'
            },
            template: ['<p>Value of name property in directive is - {{ name }}</p>',
                      '<p>Enter Name: <input type="text" ng-model="name"></p>',
                      '<p>Value of age property in directive is - {{ age }} </p>',
                      '<p>Enter new Age: <input type="text" ng-model="age"></p>',
                      '<p><input type="button" ng-click="callbackFunc()" value="Directive Button"</p>'].join('')
        };
    }]).directive('message', [function () {
        return {
            compile: function(tElement, tAttrs) {
                console.log(tAttrs.text + '-- in complie function');
                
                tElement.css('border','2px solid red'); //CSS
                console.log(angular.element(tElement)[0].classList); //DOM Manipulation
                /*
                 * Styling can be done in compile function
                 * DOM Manipulation can be done in compile function
                 */
                return {
                    pre: function (scope, iElement, iAttrs, controller) {
                        console.log(iAttrs.text + '-- in pre link function');
                        
                        iElement[0].addEventListener('click', function () {
                            iElement.append('<p>Hello World!!</p>');
                        });
                        
                    },
                    post: function (scope, iElement, iAttrs, controller) {
                        console.log(iAttrs.text + '-- in post link function');
                    }
                    
                };
            },
            controller: function ($scope, $element, $attrs) {
                console.log($attrs.text + '-- attribute in controller');
            }
        };
    }]);
});



// @ is text bind
// = two way bind
// & one way bind (callback function)